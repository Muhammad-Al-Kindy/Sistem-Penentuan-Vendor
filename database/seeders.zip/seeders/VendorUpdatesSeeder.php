<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class VendorUpdatesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('vendor_updates')->insert([
            [
                'purchase_order_id' => 1,
                'vendor_id' => 1,
                'tanggal_update' => Carbon::now()->subDays(15),
                'jenis_update' => 'Delivery Schedule',
                'keterangan' => 'Changed delivery date to next week',
                'dokumen' => 'schedule_update_001.pdf',
                'created_at' => Carbon::now()->subDays(15),
                'updated_at' => Carbon::now()->subDays(15),
            ],
            [
                'purchase_order_id' => 2,
                'vendor_id' => 2,
                'tanggal_update' => Carbon::now()->subDays(10),
                'jenis_update' => 'Quality Report',
                'keterangan' => 'Submitted monthly quality report',
                'dokumen' => 'quality_report_002.pdf',
                'created_at' => Carbon::now()->subDays(10),
                'updated_at' => Carbon::now()->subDays(10),
            ],
            [
                'purchase_order_id' => 1,
                'vendor_id' => 1,
                'tanggal_update' => Carbon::now()->subDays(5),
                'jenis_update' => 'Contact Information',
                'keterangan' => 'Updated primary contact person',
                'dokumen' => null,
                'created_at' => Carbon::now()->subDays(5),
                'updated_at' => Carbon::now()->subDays(5),
            ],
        ]);
    }
}
