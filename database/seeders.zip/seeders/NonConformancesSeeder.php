<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class NonConformancesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('non_conformances')->insert([
            [
                'goods_receipt_item_id' => 1,
                'tanggal_ditemukan' => Carbon::now()->subDays(10),
                'tanggal_respon_vendor' => Carbon::now()->subDays(8),
                'status' => 'closed',
                'keterangan' => 'Product defect identified and resolved',
                'created_at' => Carbon::now()->subDays(10),
                'updated_at' => Carbon::now()->subDays(8),
            ],
            [
                'goods_receipt_item_id' => 2,
                'tanggal_ditemukan' => Carbon::now()->subDays(5),
                'tanggal_respon_vendor' => Carbon::now()->subDays(3),
                'status' => 'responded',
                'keterangan' => 'Quality issue reported, waiting for resolution',
                'created_at' => Carbon::now()->subDays(5),
                'updated_at' => Carbon::now()->subDays(3),
            ],
        ]);
    }
}
